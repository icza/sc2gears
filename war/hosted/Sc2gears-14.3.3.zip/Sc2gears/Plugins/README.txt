
Plugins are software components that will run along with Sc2gears, but they are developed independently by 3rd party developers and vendors.

Plugins can be a great asset to make your Sc2gears and StarCraft II experience better.

Since plugins are NOT developed or maintained by me, you should have the same reservations about them
as about any applications you download from the Internet.

ONLY DOWNLOAD AND ADD PLUGINS THAT COME FROM TRUSTED SOURCES!

Plugins are distributed as folders. To add a plugin to Sc2gears, you just have to copy the plugin's folder into this folder.
You can manage your plugins from the Plugin Manager which is available from the Tools menu inside Sc2gears.

When a plugin is copied into this folder, it is disabled by default. You have to manually enable it in the Plugin Manager.

Since plugins are NOT developed by me, I take zero responsibility for what they do or how they do it.
Poorly or viciously written plugins can make your Sc2gears or your whole system slow, unstable, or can even damage it.
Plugins can also access and steal your private data.

AGAIN: ONLY DOWNLOAD AND ADD PLUGINS THAT COME FROM TRUSTED SOURCES!

More info:
https://sites.google.com/site/sc2gears/features/plugin-interface
